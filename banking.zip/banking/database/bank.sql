-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2022 at 11:46 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_account`
--

CREATE TABLE `bank_account` (
  `account_no` bigint(11) NOT NULL,
  `account_type` varchar(255) DEFAULT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `balance` float DEFAULT 1000,
  `last_withdrawal` float DEFAULT NULL,
  `last_deposit` float DEFAULT NULL,
  `created_date` datetime DEFAULT current_timestamp(),
  `updated_date` datetime DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `account_type_category` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bank_account`
--

INSERT INTO `bank_account` (`account_no`, `account_type`, `owner_name`, `balance`, `last_withdrawal`, `last_deposit`, `created_date`, `updated_date`, `bank_name`, `account_type_category`, `is_deleted`) VALUES
(135201500638, 'Investment', 'Amit', 103500, 1000, 500, '2022-12-11 17:17:17', '2022-12-11 18:21:23', 'ICICI', 'Individual', 0),
(135201500639, 'Checking', 'Vipin', 5000, 0, 1000, '2022-12-11 17:55:51', '2022-12-11 17:57:11', 'ICICI', NULL, 0),
(135201500640, 'Checking', 'Vipin', 3990, 0, 10, '2022-12-11 18:20:35', '2022-12-11 18:21:23', 'ICICI', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bank_name`
--

CREATE TABLE `bank_name` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `branch_address` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bank_name`
--

INSERT INTO `bank_name` (`id`, `name`, `branch_address`, `created_date`) VALUES
(1, 'ICICI', 'Golf city ,Noida Sector 75,201301', '2022-12-14 12:01:52'),
(2, 'HDFC', 'Connaught place ,New delhi,110001', '2022-12-14 12:02:00');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_log`
--

CREATE TABLE `transaction_log` (
  `id` int(11) NOT NULL,
  `sender_account_no` bigint(20) NOT NULL,
  `reciever_account_no` bigint(20) NOT NULL,
  `transfer_amount` float NOT NULL,
  `transaction_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction_log`
--

INSERT INTO `transaction_log` (`id`, `sender_account_no`, `reciever_account_no`, `transfer_amount`, `transaction_date`) VALUES
(1, 135201500638, 135201500639, 1000, '2022-12-14 19:51:34'),
(2, 135201500648, 135201500639, 1000, '2022-12-15 09:56:23'),
(3, 135201500638, 135201500639, 1000, '2022-12-15 16:01:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_account`
--
ALTER TABLE `bank_account`
  ADD PRIMARY KEY (`account_no`);

--
-- Indexes for table `bank_name`
--
ALTER TABLE `bank_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_log`
--
ALTER TABLE `transaction_log`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_account`
--
ALTER TABLE `bank_account`
  MODIFY `account_no` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135201500650;

--
-- AUTO_INCREMENT for table `bank_name`
--
ALTER TABLE `bank_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transaction_log`
--
ALTER TABLE `transaction_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
