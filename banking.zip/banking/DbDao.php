<?php 

abstract class dbDao{
	private $__connection;
    protected $tableName = 'bank_account';
	protected $primaryKey = 'id';

	public function __construct(){
		$this->__connectToDB(DB_USER, DB_PASS, DB_HOST, DB_DATABASE);
	}
	
	private function __connectToDB($user, $pass, $host, $database){
		$this->__connection = mysqli_connect($host, $user, $pass,$database);
        if(!$this->__connection) {
            echo "not connected";
        }
      
	}
	
	
	
	public function fetch($value, $key = NULL){
		if (is_null($key)){
			$key = $this->primaryKey;
		}
		 $sql = "select * from {$this->tableName} where {$key}='{$value}'";
		$results = mysqli_query($this->__connection,$sql);
		$rows = array();
		
		while ($result = mysqli_fetch_array($results,MYSQLI_ASSOC)) {
			$rows[] = $result;
		}
		return $rows;
	}
	
	public function update($keyedArray){
		$sql = "update {$this->tableName} set ";
		$updates = array();
		
		foreach ($keyedArray as $column=> $value) {
			$updates[] = "{$column}={$value}";
		}
		
		$sql .= implode(',', $updates);
		 $sql .= " where account_no='{$keyedArray["account_no"]}'";
		 //print_r($sql);die();
		return mysqli_query($this->__connection,$sql);
	}
	public function insert_log($sendor_account_no,$reciever_account_no,$transfer_amount)
    {
		
        $sql = 'INSERT INTO transaction_log (sender_account_no,reciever_account_no,transfer_amount) VALUES ('.$sendor_account_no.','.$reciever_account_no.','.$transfer_amount.')';
       //print_r($sql);
	   return mysqli_query($this->__connection,$sql);
    }
	
	public function getbankdetail()
    {
		
        $sql = "select name as Bank_Name,branch_address as Branch_Address from bank_name";
		$results = mysqli_query($this->__connection,$sql);
		$rows = array();
		
		while ($result = mysqli_fetch_array($results,MYSQLI_ASSOC)) {
			$rows[] = $result;
		}
		return $rows;
    }
	
	public function insert_in_account($dataArray){
		$getColumnsKeys = array_keys($dataArray);
		$implodeColumnKeys = implode(",",$getColumnsKeys);
		
		$getValues = array_values($dataArray);
		$implodeValues = "'".implode("','",$getValues)."'";
		$sql = "insert into $this->tableName (".$implodeColumnKeys.") values (".$implodeValues.")";
		return mysqli_query($this->__connection,$sql);
	}
	
	public function add($account_type,$owner_name,$bank_name,$account_type_category)
    {
		
        $sql = 'INSERT INTO bank_account (account_type,owner_name,bank_name,account_type_category) VALUES ("'.$account_type.'","'.$owner_name.'","'.$bank_name.'","'.$account_type_category.'")';
       //print_r($sql);
	
	   $result= mysqli_query($this->__connection,$sql);
	   
	   if ($result === TRUE) {
		  $last_id = $this->__connection->insert_id;
		  $response[]= "Account created successfully. Your account no is: " . $last_id;
		} else {
		  $response[]= "Error: " . $sql . "<br>" . $conn->error;
		}
		
		return $response;
    }
	
	public function getaccountlist()
    {
		
        $sql = "select account_no,owner_name,balance from bank_account where is_deleted=0";
		$results = mysqli_query($this->__connection,$sql);
		$rows = array();
		
		while ($result = mysqli_fetch_array($results,MYSQLI_ASSOC)) {
			$rows[] = $result;
		}
		return $rows;
    }
	
	public function getsingleaccountdetail($account_no)
    {
		
        $sql = "select account_no,account_type,account_type_category,owner_name,balance from bank_account where account_no=$account_no and is_deleted=0";
		$results = mysqli_query($this->__connection,$sql);
		$count=mysqli_num_rows($results);
		$rows = array();
		if($count!=0)
		{
		while ($result = mysqli_fetch_array($results,MYSQLI_ASSOC)) {
			$rows[] = $result;
		}
		}
		else
		{
			$rows[] =['status'=>0,'msg'=>'Your account is inactive,Kindly contact your branch manager to activate account'];
		}
		return $rows;
    }
	
	public function updateaccount($account_no,$account_type,$account_type_category)
    {
        $sql = "update bank_account set account_type='$account_type',account_type_category='$account_type_category' where account_no=$account_no and is_deleted=0";
		$result= mysqli_query($this->__connection,$sql);
		$affected_row= mysqli_affected_rows($this->__connection);
		$rows = array();
		if($affected_row != 0 )
		{
			$rows[] =['status'=>1,'msg'=>'Your account detail updated succesfully'];
		}
		else
		{
			$rows[] =['status'=>0,'msg'=>'Your account is inactive,Kindly contact your branch manager to activate account'];
		}
		return $rows;
    }
	
	public function getaccountwithtype($account_type)
    {
		
        $sql = "select account_no,owner_name,balance,account_type_category from bank_account where account_type='$account_type' and is_deleted=0";
		//print_r($sql);
		$results = mysqli_query($this->__connection,$sql);
		$rows = array();
		
		while ($result = mysqli_fetch_array($results,MYSQLI_ASSOC)) {
			$rows[] = $result;
		}
		return $rows;
    }
	
	public function activateaccount($account_no)
    {
        $sql = "update bank_account set is_deleted=0 where account_no=$account_no";
		$result= mysqli_query($this->__connection,$sql);
		$affected_row= mysqli_affected_rows($this->__connection);
		$rows = array();
		if($affected_row != 0 )
		{
			$rows[] =['status'=>1,'msg'=>'Your account detail updated succesfully'];
		}
		else
		{
			$rows[] =['status'=>0,'msg'=>'Your account is not updated,Kindly check'];
		}
		return $rows;
    }
}

class userDAO extends dbDao{


}


define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_HOST', 'localhost');
define('DB_DATABASE', 'bank');

$user = new userDAO();

?>