<?php
ini_set("display_errors",1);
require('DbDao.php');


class BankAccount {
    private $balance; 
    public $owner; 
    public $account_type;
    public $bank;
    public $account_no;

    public function __construct($bank,$owner,$account_no,$account_type)
    {
     $this->owner=   $owner;
     $this->bank=   $bank;
     $this->account_no=   $account_no;
     $this->account_type=   $account_type;

    }
    public function checkBalance($dbobj) {
        $response= $dbobj->fetch($this->account_no, 'account_no');
        $this->balance=$response[0]['balance'];
        if(is_array($response) && count($response)>0) {
            $this->balance=$response[0]['balance'];
            }
            else {
                $this->balance="Account does not exist";
            }
		$response=['status'=>1,'msg'=>"Account Balance Fetch Successfully",'Current Balance'=>$this->balance." Rs"];
        echo json_encode($response);
      }

     public function checkAccountOwner($dbobj) {
        $response= $dbobj->fetch($this->account_no, 'account_no');
        if(is_array($response) && count($response)>0) {
        $this->owner=$response[0]['owner_name'];
		$account_holder_name= $this->owner;
        }
        else {
            $this->owner="Invalid account";
        }
		$response=['status'=>1,'msg'=>"Account holder name is. ".$account_holder_name."."];
        echo json_encode($response);
        
     } 
     public function checkAccountType($dbobj,$account_no) {
        $response= $dbobj->fetch($account_no, 'account_no');
		//print_r($response);die();
        if(is_array($response) && count($response)>0) {
        $this->account_type=$response[0]['account_type'];
		$this->account_type_category=$response[0]['account_type_category'];
        if($this->account_type=="Individual") {
            $this->account_type=$response[0]['account_type_category'];
        }
        }
        else {
            echo "Invalid account";exit();
        }
        return $this->account_type_category;
     }
    
    public function Deposit($dbobj,$amt,$account_no) {
        if($amt>0) {
            $array=["account_no"=>$account_no,"balance"=>"balance+'".$amt."'","last_deposit"=>$amt];
            if($dbobj->update($array)) {
             $this->balance=$this->balance-$amt;
              $response=['status'=>1,'msg'=>"".$amt." Rs credited your account"];
            }
            else {
                 $response=['status'=>0,'msg'=>"Transaction failed"];
            }
        }
        else {
             $response=['status'=>0,'msg'=>"invalid_amt"];
        }
		echo json_encode($response);
    }

    public function withDrawl($dbobj,$amt,$account_no) {
      $account_type_category=  $this->checkAccountType($dbobj,$account_no);
	  //print_r($account_type);
	  //die();
        if($amt>0) {
            if($account_type_category=='Individual' && $amt>500) {
                $response=['status'=>0,'msg'=>"Amount should not greater than 500 INR in case of individual account"];
            }
			else
			{
            $array=["account_no"=>$account_no,"balance"=>"balance-$amt","last_withdrawal"=>$amt];
           // echo "<pre>";print_r($array);die;
            if($dbobj->update($array)) {
             $this->balance=$this->balance-$amt;
             $response=['status'=>1,'msg'=>"Transaction Succesfull",'Withdrawal Amount'=>$amt];
		
            }
            else {
                 $response=['status'=>0,'msg'=>"Transaction failed"];
            }
			
			}
        }
        else {
             $response=['status'=>0,'msg'=>"invalid_amt"];
        }
		echo json_encode($response);
		 
    }
    public function Transfer($dbObj,$transfer_account_no,$tranferryAccnt,$transferAmount) {
		$sendor_account_no=$transfer_account_no;
		
		//print_r($sendor_account_no);
		//die();
        if($transferAmount>0) {
            $array=["account_no"=>$transfer_account_no,"balance"=>"balance-'".$transferAmount."'","last_withdrawal"=>$transferAmount];
            if($dbObj->update($array)) {
             $this->balance=$this->balance-$transferAmount;
             //transer amount to benefeciary
            $beneficiaryArray=["account_no"=>$tranferryAccnt,"balance"=>"balance+'".$transferAmount."'","last_deposit"=>$transferAmount];
             if($dbObj->update($beneficiaryArray)) {
				 $dbObj->insert_log($sendor_account_no,$tranferryAccnt,$transferAmount);
                 $response=['status'=>1,'msg'=>"Amount succesfully transfer to beneficiary account"];
				
             }
             else {
                 $response=['status'=>0,'msg'=>"Transaction failed"];
             }
            }
            else {
                 $response=['status'=>0,'msg'=>"Transaction failed"];
            }
        }
        else {
             $response=['status'=>0,'msg'=>"invalid_amt"];
        }
		
		echo json_encode($response);
		
    }
	
	public function getbankdetail($dbObj)
	{
		$response= $dbObj->getbankdetail();
		echo json_encode($response);
		
	}
	
	public function add($dbObj,$account_type,$owner_name,$bank_name,$account_type_category)
	{
		$response= $dbObj->add($account_type,$owner_name,$bank_name,$account_type_category);
		echo json_encode($response);
		
	}
	
	public function getaccountlist($dbObj)
	{
		$response= $dbObj->getaccountlist();
		echo json_encode($response);
		
	}
	
	public function getsingleaccountdetail($dbObj,$account_no)
	{
		$response= $dbObj->getsingleaccountdetail($account_no);
		//print_r($response);
		//die();
		echo json_encode($response);
		
	}
	
	public function softdelete($dbObj,$account_no)
	{
		//$response= $dbObj->softdelete($account_no);
		$beneficiaryArray=["account_no"=>$account_no,"is_deleted"=>1];
		if($dbObj->update($beneficiaryArray)) {
		
                 $response=['status'=>1,'msg'=>"Now your account is inactive state"];
				
             }
		echo json_encode($response);
		
	}
	
	public function updateaccount($dbObj,$account_no,$account_type,$account_type_category)
	{
		$response = $dbObj->updateaccount($account_no,$account_type,$account_type_category);
		
		echo json_encode($response);
		
	}
	
	public function getaccountwithtype($dbObj,$account_type)
	{
		$response= $dbObj->getaccountwithtype($account_type);
		echo json_encode($response);
		
	}
	
	public function activateaccount($dbObj,$account_no)
	{
		$response = $dbObj->activateaccount($account_no);
		
		echo json_encode($response);
		
	}
	
	

}
$bank="baroda";
$owner="amit";
$account_no="312233445566";
$account_type="Individual";
$dbObj=new userDAO();  // instantiate database class
$obj= new BankAccount($bank,$owner,$account_no,$account_type);
//$obj->checkBalance($dbObj);
//$obj->checkAccountOwner($dbObj);

//$obj->withDrawl($dbObj,'400');
//$obj->Deposit($dbObj,'200');

$tranferryAccnt="33543543534543";
$transferAmount="10";
//$obj->Transfer($dbObj,$tranferryAccnt,$transferAmount);

$method_name=$_GET['method'];

if($method_name=='getbankdetail')
{
	$obj->getbankdetail($dbObj);
}
if($method_name=='add')
{
	$account_type= $_POST['account_type'];
	$owner_name= $_POST['owner_name'];
	$bank_name= $_POST['bank_name'];
	$account_type_category= $_POST['account_type_category'];
	
	//$array=["account_type"=>$account_type,"owner_name"=>$owner_name,"bank_name"=>$bank_name,"account_type_category"=>$account_type_category];
	
	//$obj->add($dbObj,$array);
	$obj->add($dbObj,$account_type,$owner_name,$bank_name,$account_type_category);
	
}

if($method_name=='getaccountlist')
{
	$obj->getaccountlist($dbObj);
}

if($method_name=='getsingleaccountdetail')
{
	$account_no= $_POST['account_no'];
	$obj->getsingleaccountdetail($dbObj,$account_no);
}


if($method_name=='accountdeposit')
{
	$account_no= $_POST['account_no'];
	$amt= $_POST['amount'];
	$obj->Deposit($dbObj,$amt,$account_no);
}

if($method_name=='accountwithdrwal')
{
	$account_no= $_POST['account_no'];
	$amt= $_POST['amount'];
	$obj->withDrawl($dbObj,$amt,$account_no);
}


if($method_name=='moneytransfer')
{
	$transfer_account_no= $_POST['transfer_account_no'];
	$tranferryAccnt= $_POST['tranferryAccnt'];
	$transferAmount= $_POST['transferAmount'];
	$obj->Transfer($dbObj,$transfer_account_no,$tranferryAccnt,$transferAmount);
}

if($method_name=='softdelete')
{
	$account_no= $_POST['account_no'];
	$obj->softdelete($dbObj,$account_no);
}

if($method_name=='updateaccount')
{
	$account_no= $_POST['account_no'];
	$account_type= $_POST['account_type'];
	$account_type_category= $_POST['account_type_category'];

	$obj->updateaccount($dbObj,$account_no,$account_type,$account_type_category);
	
}

if($method_name=='getaccountwithtype')
{
	$account_type= $_POST['account_type'];
	$obj->getaccountwithtype($dbObj,$account_type);
}
if($method_name=='activateaccount')
{
	$account_no= $_POST['account_no'];
	$obj->activateaccount($dbObj,$account_no);
}

?>
